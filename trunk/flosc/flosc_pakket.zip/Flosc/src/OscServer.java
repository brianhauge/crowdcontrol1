// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OscServer.java

import java.io.IOException;
import java.io.PrintStream;
import java.net.*;
import java.util.Vector;

public class OscServer extends Thread
{

    public OscServer(int port, Gateway gateway)
    {
        this.port = port;
        this.gateway = gateway;
        Gateway.writeActivity("OscServer created...");
    }

    public void run()
    {
        try
        {
            oscSocket = new DatagramSocket(port);
            Gateway.writeActivity((new StringBuilder("UDP OSC server started on port: ")).append(port).toString());
            i = true;
            do
            {
                OscPacket oscp;
                do
                {
                    byte datagram[] = new byte[16384];
                    DatagramPacket packet = new DatagramPacket(datagram, datagram.length);
                    oscSocket.receive(packet);
                    Gateway.writeActivity("Received UDP packet, parsing OSC...");
                    oscp = new OscPacket();
                    oscp.address = packet.getAddress();
                    oscp.port = packet.getPort();
                    parseOscPacket(datagram, packet.getLength(), oscp);
                } while(!oscp.address.isLoopbackAddress());
                gateway.broadcastMessage(oscp.getXml());
            } while(true);
        }
        catch(IOException ioe)
        {
        	if (i == true)
            Gateway.writeActivity("Server error...Stopping UDP OSC server");
        }
    }

    public void parseOscPacket(byte datagram[], int n, OscPacket packet)
    {
        if(n % 4 != 0)
        {
            Gateway.writeActivity((new StringBuilder("SynthControl packet size (")).append(n).append(") not a multiple of 4 bytes, dropped it.").toString());
            return;
        }
        String dataString = new String(datagram);
        if(n >= 8 && dataString.startsWith("#bundle"))
        {
            if(n < 16)
            {
                Gateway.writeActivity((new StringBuilder("Bundle message too small (")).append(n).append(" bytes) for time tag, dropped it.").toString());
                return;
            }
            Long time = new Long(Bytes.toLong(Bytes.copy(datagram, 8, 8)));
            packet.setTime(time.longValue());
            int size;
            for(int i = 16; i < n; i += 4 + size)
            {
                size = Bytes.toInt(Bytes.copy(datagram, i, i + 4));
                if(size % 4 != 0)
                {
                    Gateway.writeActivity((new StringBuilder("Bad size count")).append(size).append("in bundle (not a multiple of 4)").toString());
                    return;
                }
                if(size + i + 4 > n)
                {
                    Gateway.writeActivity((new StringBuilder("Bad size count")).append(size).append("in bundle").append("(only").append(n - i - 4).append("bytes left in entire bundle)").toString());
                    return;
                }
                byte remaining[] = Bytes.copy(datagram, i + 4);
                parseOscPacket(remaining, size, packet);
            }

        } else
        {
            Vector nameAndData = getStringAndData(datagram, n);
            String name = (String)nameAndData.firstElement();
            OscMessage message = new OscMessage(name);
            byte data[] = (byte[])nameAndData.lastElement();
            Vector typesAndArgs[] = getTypesAndArgs(data);
            message.setTypesAndArgs(typesAndArgs[0], typesAndArgs[1]);
            packet.addMessage(message);
        }
    }

    public Vector getStringAndData(byte block[], int stringLength)
    {
        Vector v = new Vector();
        if(stringLength % 4 != 0)
        {
            Gateway.writeActivity("printNameAndArgs: bad boundary");
            return v;
        }
        int i;
        for(i = 0; block[i] != 0; i++)
            if(i >= stringLength)
            {
                Gateway.writeActivity("printNameAndArgs: Unreasonably long string");
                return v;
            }

        v.addElement(new String(Bytes.copy(block, 0, i)));
        for(i++; i % 4 != 0; i++)
        {
            if(i >= stringLength)
            {
                Gateway.writeActivity("printNameAndArgs: Unreasonably long string");
                return v;
            }
            if(block[i] != 0)
            {
                Gateway.writeActivity("printNameAndArgs: Incorrectly padded string.");
                return v;
            }
        }

        v.addElement(new Integer(i));
        v.addElement(Bytes.copy(block, i));
        return v;
    }

    public Vector[] getTypesAndArgs(byte block[])
    {
        int n = block.length;
        Vector va[] = new Vector[2];
        if(n != 0)
            if(block[0] == 44)
            {
                if(block[1] != 44)
                    va = getTypeTaggedArgs(block);
                else
                    va = getHeuristicallyTypeGuessedArgs(block);
            } else
            {
                va = getHeuristicallyTypeGuessedArgs(block);
            }
        return va;
    }

    public Vector[] getTypeTaggedArgs(byte block[])
    {
        Vector typeVector = new Vector();
        Vector argVector = new Vector();
        int p = 0;
        Vector typesAndArgs = getStringAndData(block, block.length);
        byte args[] = (byte[])typesAndArgs.lastElement();
        for(int thisType = 1; block[thisType] != 0; thisType++)
            switch(block[thisType])
            {
            case 91: // '['
                typeVector.addElement(new Character('['));
                break;

            case 93: // ']'
                typeVector.addElement(new Character(']'));
                break;

            case 99: // 'c'
            case 105: // 'i'
            case 109: // 'm'
            case 114: // 'r'
                typeVector.addElement(new Character('i'));
                argVector.addElement(new Integer(Bytes.toInt(Bytes.copy(args, p, p + 4))));
                p += 4;
                break;

            case 102: // 'f'
                typeVector.addElement(new Character('f'));
                argVector.addElement(new Float(Bytes.toFloat(Bytes.copy(args, p, p + 4))));
                p += 4;
                break;

            case 104: // 'h'
            case 116: // 't'
                typeVector.addElement(new Character('h'));
                argVector.addElement(new Long(Bytes.toLong(Bytes.copy(args, p, p + 8))));
                p += 8;
                break;

            case 100: // 'd'
                typeVector.addElement(new Character('d'));
                argVector.addElement(new Double(Bytes.toDouble(Bytes.copy(args, p, p + 8))));
                p += 8;
                break;

            case 83: // 'S'
            case 115: // 's'
                typeVector.addElement(new Character('s'));
                byte remaining[] = Bytes.copy(args, p);
                Vector v = getStringAndData(remaining, remaining.length);
                argVector.addElement((String)v.firstElement());
                p += ((Integer)v.elementAt(1)).intValue();
                break;

            case 84: // 'T'
                typeVector.addElement(new Character('T'));
                break;

            case 70: // 'F'
                typeVector.addElement(new Character('F'));
                break;

            case 78: // 'N'
                typeVector.addElement(new Character('N'));
                break;

            case 73: // 'I'
                typeVector.addElement(new Character('I'));
                break;

            default:
                Gateway.writeActivity((new StringBuilder("[Unrecognized type tag ")).append(block[thisType]).append("]").toString());
                break;
            }

        Vector returnValue[] = new Vector[2];
        returnValue[0] = typeVector;
        returnValue[1] = argVector;
        return returnValue;
    }

    public Vector[] getHeuristicallyTypeGuessedArgs(byte block[])
    {
        Gateway.writeActivity("Bad OSC packet: No type tags");
        return new Vector[2];
    }

    public void sendPacket(OscPacket packet)
    {
        try
        {
            Gateway.writeActivity("OscServer sending UDP packet...");
            outSocket.send(packet);
        }
        catch(IOException ioe)
        {
            Gateway.writeActivity("sendPacket error...Stopping UDP OSC server");
            killServer();
        }
    }

    public void killServer()
    {
        oscSocket.close();
        i = false;
        Gateway.writeActivity("UDP OSC server stopped");
    }

    private DatagramSocket oscSocket;
    private int port;
    private boolean i;
    private Gateway gateway;
    private static OscSocket outSocket;

    static 
    {
        try
        {
            outSocket = new OscSocket();
        }
        catch(SocketException se)
        {
            se.printStackTrace();
        }
    }
}
