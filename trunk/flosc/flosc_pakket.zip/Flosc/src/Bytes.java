// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Bytes.java


public class Bytes
{

    public Bytes()
    {
    }

    public static int toInt(byte b[])
    {
        return (b[3] & 0xff) + ((b[2] & 0xff) << 8) + ((b[1] & 0xff) << 16) + ((b[0] & 0xff) << 24);
    }

    public static long toLong(byte b[])
    {
        return ((long)b[7] & 255L) + (((long)b[6] & 255L) << 8) + (((long)b[5] & 255L) << 16) + (((long)b[4] & 255L) << 24) + (((long)b[3] & 255L) << 32) + (((long)b[2] & 255L) << 40) + (((long)b[1] & 255L) << 48) + (((long)b[0] & 255L) << 56);
    }

    public static float toFloat(byte b[])
    {
        int i = toInt(b);
        return Float.intBitsToFloat(i);
    }

    public static double toDouble(byte b[])
    {
        long l = toLong(b);
        return Double.longBitsToDouble(l);
    }

    public static byte[] toBytes(int n)
    {
        return toBytes(n, new byte[4]);
    }

    public static byte[] toBytes(int n, byte b[])
    {
        b[3] = (byte)n;
        n >>>= 8;
        b[2] = (byte)n;
        n >>>= 8;
        b[1] = (byte)n;
        n >>>= 8;
        b[0] = (byte)n;
        return b;
    }

    public static byte[] toBytes(long n)
    {
        return toBytes(n, new byte[8]);
    }

    public static byte[] toBytes(long n, byte b[])
    {
        b[7] = (byte)(int)n;
        n >>>= 8;
        b[6] = (byte)(int)n;
        n >>>= 8;
        b[5] = (byte)(int)n;
        n >>>= 8;
        b[4] = (byte)(int)n;
        n >>>= 8;
        b[3] = (byte)(int)n;
        n >>>= 8;
        b[2] = (byte)(int)n;
        n >>>= 8;
        b[1] = (byte)(int)n;
        n >>>= 8;
        b[0] = (byte)(int)n;
        return b;
    }

    public static boolean areEqual(byte a[], byte b[])
    {
        int aLength = a.length;
        if(aLength != b.length)
            return false;
        for(int i = 0; i < aLength; i++)
            if(a[i] != b[i])
                return false;

        return true;
    }

    public static byte[] append(byte a[], byte b[])
    {
        byte z[] = new byte[a.length + b.length];
        System.arraycopy(a, 0, z, 0, a.length);
        System.arraycopy(b, 0, z, a.length, b.length);
        return z;
    }

    public static byte[] append(byte a[], byte b[], byte c[])
    {
        byte z[] = new byte[a.length + b.length + c.length];
        System.arraycopy(a, 0, z, 0, a.length);
        System.arraycopy(b, 0, z, a.length, b.length);
        System.arraycopy(c, 0, z, a.length + b.length, c.length);
        return z;
    }

    public static byte[] copy(byte b[], int pos)
    {
        return copy(b, pos, b.length - pos);
    }

    public static byte[] copy(byte b[], int pos, int length)
    {
        byte z[] = new byte[length];
        System.arraycopy(b, pos, z, 0, length);
        return z;
    }

    public static void merge(byte src[], byte dest[], int srcpos, int destpos, int length)
    {
        System.arraycopy(src, srcpos, dest, destpos, length);
    }

    public static void merge(byte src[], byte dest[], int pos)
    {
        System.arraycopy(src, 0, dest, pos, src.length);
    }

    public static void merge(byte src[], byte dest[])
    {
        System.arraycopy(src, 0, dest, 0, src.length);
    }

    public static void merge(byte src[], byte dest[], int pos, int length)
    {
        System.arraycopy(src, 0, dest, pos, length);
    }

    public static String toString(byte b[], int offset, int length)
    {
        char buf[] = new char[length * 2];
        int i = offset;
        int j = 0;
        for(; i < offset + length; i++)
        {
            int k = b[i];
            buf[j++] = hexDigits[k >>> 4 & 0xf];
            buf[j++] = hexDigits[k & 0xf];
        }

        return new String(buf);
    }

    public static String toString(byte b[])
    {
        return toString(b, 0, b.length);
    }

    private static final char hexDigits[] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
        'A', 'B', 'C', 'D', 'E', 'F'
    };

}
