// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TcpServer.java

import java.io.*;
import java.net.*;
import java.util.Iterator;
import java.util.Vector;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class TcpServer extends Thread
{

    public TcpServer(int port, Gateway gateway)
    {
        clients = new Vector();
        this.port = port;
        this.gateway = gateway;
        Gateway.writeActivity("TcpServer created...");
    }

    public void run()
    {
        try
        {
            server = new ServerSocket(port);
            Gateway.writeActivity((new StringBuilder("TCP XML/Flash server started on port: ")).append(port).toString());
            i = true;
            do
            {
                java.net.Socket socket = server.accept();
                TcpClient client = new TcpClient(this, socket);
                Gateway.writeActivity((new StringBuilder(String.valueOf(client.getIP()))).append(" connected to TCP XML/Flash server.").toString());
                clients.addElement(client);
                client.start();
            } while(true);
        }
        catch(IOException ioe)
        {
        	if (i == true)
            Gateway.writeActivity("Server error...Stopping TCP XML/Flash server");
        }
        
    }

    public synchronized void broadcastMessage(String message)
    {
        message = (new StringBuilder(String.valueOf(message))).append('\0').toString();
        TcpClient client;
        for(Iterator iterator = clients.iterator(); iterator.hasNext(); client.send(message))
            client = (TcpClient)iterator.next();

    }

    public void handleOsc(String oscxml)
        throws UnknownHostException
    {
        Gateway.writeActivity(oscxml);
        Gateway.writeActivity("Received TCP packet, parsing XML...");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try
        {
            DocumentBuilder builder = factory.newDocumentBuilder();
            document = builder.parse(new InputSource(new StringReader(oscxml)));
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        catch(ParserConfigurationException e)
        {
            e.printStackTrace();
        }
        catch(SAXException e)
        {
            e.printStackTrace();
        }
        Node oscNode1 = null;
        if(document.getElementsByTagName("OSCPACKET").getLength() < 1)
        {
            Gateway.writeActivity("Parse error: data outside OSCPACKET element");
            return;
        }
        OscPacket packet = new OscPacket();
        Node oscNode = document.getElementsByTagName("OSCPACKET").item(0);
        packet.setTime(Long.parseLong(oscNode.getAttributes().getNamedItem("TIME").getNodeValue()));
        packet.setAddress(InetAddress.getByName(oscNode.getAttributes().getNamedItem("ADDRESS").getNodeValue()));
        packet.setPort(Integer.parseInt(oscNode.getAttributes().getNamedItem("PORT").getNodeValue()));
        NodeList oscMessages = document.getElementsByTagName("MESSAGE");
        if(oscMessages.getLength() < 1)
            return;
        for(int i = 0; i < oscMessages.getLength(); i++)
        {
            Node xmlMessage = oscMessages.item(i);
            OscMessage message = new OscMessage(xmlMessage.getAttributes().getNamedItem("NAME").getNodeValue());
            NodeList oscArguments = xmlMessage.getChildNodes();
            for(int j = 0; j < oscArguments.getLength(); j++)
            {
                Node argument = oscArguments.item(j);
                if(argument.getNodeName().equals("ARGUMENT"))
                {
                    char argType = argument.getAttributes().getNamedItem("TYPE").getNodeValue().charAt(0);
                    String argValue = argument.getAttributes().getNamedItem("VALUE").getNodeValue();
                    Character type = new Character(argType);
                    switch(argType)
                    {
                    case 99: // 'c'
                    case 105: // 'i'
                    case 109: // 'm'
                    case 114: // 'r'
                        Integer in = Integer.valueOf(argValue);
                        message.addArg(type, in);
                        break;

                    case 102: // 'f'
                        Float f = Float.valueOf(argValue);
                        message.addArg(type, f);
                        break;

                    case 104: // 'h'
                    case 116: // 't'
                        Long l = Long.valueOf(argValue);
                        message.addArg(type, l);
                        break;

                    case 100: // 'd'
                        Double d = Double.valueOf(argValue);
                        message.addArg(type, d);
                        break;

                    case 83: // 'S'
                    case 115: // 's'
                        message.addArg(type, unescape(argValue));
                        break;
                    }
                }
            }

            packet.addMessage(message);
        }

        gateway.sendPacket(packet);
    }

    public String unescape(String s)
    {
        String retval = "";
        try
        {
            retval = URLDecoder.decode(s, "UTF-8");
        }
        catch(UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
        return retval;
    }

    public void removeClient(TcpClient client)
    {
        Gateway.writeActivity((new StringBuilder(String.valueOf(client.getIP()))).append(" has disconnected from the server.").toString());
        clients.removeElement(client);
    }

    public void killServer()
    {
        try
        {
            server.close();
            i = false;
            Gateway.writeActivity("TCP XML/Flash server stopped");
        }
        catch(IOException ioe)
        {
            Gateway.writeActivity("Error while stopping TCP XML/Flash server");
        }
    }

    public Document document;
    private Vector clients;
    private int port;
    private boolean i;
    ServerSocket server;
    Gateway gateway;
}
