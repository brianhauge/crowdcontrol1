import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.net.URL;
import java.util.Calendar;

import javax.swing.*;


public class Gateway extends JFrame
    implements ActionListener
{

    public Gateway(int oscPort, int flashPort)
    {
        _oscPort = oscPort;
        _flashPort = flashPort;
    }

    public void startServers()
    {
        System.out.println("Attempting to start OSC / Flash Gateway server");
        oscServer = new OscServer(_oscPort, this);
        tcpServer = new TcpServer(_flashPort, this);
        oscServer.start();
        tcpServer.start();
    }

    public void stopServers()
    {
        oscServer.killServer();
        tcpServer.killServer();
    }

    public void broadcastMessage(String message)
    {
        tcpServer.broadcastMessage(message);
    }

    public void sendPacket(OscPacket packet)
    {
        Gateway.writeActivity("Gateway transporting OSC packet.");
        oscServer.sendPacket(packet);
    }

    private static void createAndShowGUI()
    {
        myGateway.setSize(585, 455);
        myGateway.setTitle("Flosc 2.0");
        myGateway.setLayout(new FlowLayout(0));
        myGateway.setResizable(false);
        MenuBar menubar = new MenuBar();
        Menu menu = new Menu("File");
        MenuItem quitItem = new MenuItem("quit");
        quitItem.addActionListener(myGateway);
        menu.add(quitItem);
        menubar.add(menu);
        myGateway.setMenuBar(menubar);
        myGateway.setVisible(true);
        JLabel flashportLabel = new JLabel("CC Flash port:");
        myGateway.getContentPane().add(flashportLabel);
        myGateway.flashportInput = new JTextField(10);
        myGateway.flashportInput.setText(Integer.valueOf(myGateway._flashPort).toString());
        myGateway.getContentPane().add(myGateway.flashportInput);
        JLabel oscPortLabel = new JLabel("CC Max port: ");
        myGateway.getContentPane().add(oscPortLabel);
        myGateway.oscPortInput = new JTextField(10);
        myGateway.oscPortInput.setText(Integer.valueOf(myGateway._oscPort).toString());
        myGateway.getContentPane().add(myGateway.oscPortInput);
        myGateway.startButton = new Button("Start");
        myGateway.startButton.addActionListener(myGateway);
        myGateway.getContentPane().add(myGateway.startButton);
        JLabel consoleOutputLabel = new JLabel("Output:");
        myGateway.getContentPane().add(consoleOutputLabel);
        myGateway.consoleOutput = new JTextArea(21, 50);
        myGateway.consoleOutput.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(myGateway.consoleOutput);
        scrollPane.setVerticalScrollBarPolicy(
        		JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        myGateway.getContentPane().add(scrollPane);
        myGateway.clearConsole = new Button("Clear console");
        myGateway.getContentPane().add(myGateway.clearConsole);
        myGateway.clearConsole.addActionListener(myGateway);
        if(SystemTray.isSupported())
        {
            SystemTray systemTray = SystemTray.getSystemTray();
            URL url = myGateway.getClass().getResource("tray.png");
            Image image = Toolkit.getDefaultToolkit().getImage(url);
            PopupMenu popupMenu = new PopupMenu();
            myGateway.startItem = new MenuItem("Start Flosc Server");
            myGateway.startItem.setActionCommand("Start");
            myGateway.startItem.addActionListener(myGateway);
            popupMenu.add(myGateway.startItem);
            MenuItem quitItem2 = new MenuItem("quit");
            quitItem2.addActionListener(myGateway);
            popupMenu.add(quitItem2);
            TrayIcon trayIcon = new TrayIcon(image, "Flosc", popupMenu);
            trayIcon.addActionListener(myGateway);
            try
            {
                systemTray.add(trayIcon);
            }
            catch(AWTException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static void main(String args[])
    {
        myGateway = new Gateway(1250, 3000);
        SwingUtilities.invokeLater(new Runnable() {

            public void run()
            {
                Gateway.createAndShowGUI();
            }

        }
);
    }

    public void actionPerformed(ActionEvent arg0)
    {
        String str = arg0.getActionCommand();
        if(str == null)
        {
            if(myGateway.isVisible())
                myGateway.setVisible(false);
            else
                myGateway.setVisible(true);
        } else
        if(str.equals("Clear console"))
            {
                myGateway.consoleOutput.setText("");
        } else
        if(str.equals("Start"))
        {
            myGateway.startButton.setLabel("Stop");
            myGateway.startButton.setActionCommand("Stop");
            myGateway.startItem.setLabel("Stop Flosc Server");
            myGateway.startItem.setActionCommand("Stop");
            myGateway.oscPortInput.setEditable(false);
            myGateway.flashportInput.setEditable(false);
            Integer iFlashPort = new Integer(myGateway.flashportInput.getText());
            myGateway._flashPort = iFlashPort.intValue();
            Integer iOSCPort = new Integer(myGateway.oscPortInput.getText());
            myGateway._oscPort = iOSCPort.intValue();
            
            startServers();
        } else
        if(str.equals("Stop"))
        {
            myGateway.startButton.setLabel("Start");
            myGateway.startButton.setActionCommand("Start");
            myGateway.startItem.setLabel("Start Flosc Server");
            myGateway.startItem.setActionCommand("Start");
            stopServers();
            myGateway.oscPortInput.setEditable(true);
            myGateway.flashportInput.setEditable(true);
        } else
        if(str.equals("quit"))
            System.exit(0);
    }
    
    public static void writeActivity(String activity)
    {
        Calendar cal = Calendar.getInstance();
        activity = (new StringBuilder("[")).append(cal.get(2)).append("/").append(cal.get(5)).append("/").append(cal.get(1)).append(" ").append(cal.get(11)).append(":").append(cal.get(12)).append(":").append(cal.get(13)).append("] ").append(activity).append("\n").toString();
        myGateway.consoleOutput.append(activity);
    }

    private static final long serialVersionUID = 1L;
    private OscServer oscServer;
    private TcpServer tcpServer;
    private static Gateway myGateway;
    private int _oscPort;
    private int _flashPort;
    private JTextField flashportInput;
    public JTextArea consoleOutput;
    private JTextField oscPortInput;
    private Button startButton;
    private Button clearConsole;
    private MenuItem startItem;

}
