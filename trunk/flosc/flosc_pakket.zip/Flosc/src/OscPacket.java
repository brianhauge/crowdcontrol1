// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OscPacket.java

import java.io.*;
import java.net.InetAddress;
import java.util.Enumeration;
import java.util.Vector;

public class OscPacket
{

    public OscPacket()
    {
        time = 0L;
        messages = new Vector();
    }

    public OscPacket(long time, InetAddress address, int port)
    {
        this.time = time;
        messages = new Vector();
        this.address = address;
        this.port = port;
    }

    public void setTime(long time)
    {
        this.time = time;
    }

    public void setAddress(InetAddress address)
    {
        this.address = address;
    }

    public void setPort(int port)
    {
        this.port = port;
    }

    public void addMessage(OscMessage message)
    {
        messages.addElement(message);
    }

    public InetAddress getAddress()
    {
        return address;
    }

    public int getPort()
    {
        return port;
    }

    public String getXml()
    {
        String xml = "";
        xml = (new StringBuilder(String.valueOf(xml))).append("<OSCPACKET ADDRESS=\"").append(address.getHostAddress()).append("\" PORT=\"").append(port).append("\" TIME=\"").append(time).append("\">").toString();
        for(Enumeration m = messages.elements(); m.hasMoreElements();)
        {
            OscMessage mess = (OscMessage)m.nextElement();
            xml = (new StringBuilder(String.valueOf(xml))).append(mess.getXml()).toString();
        }

        xml = (new StringBuilder(String.valueOf(xml))).append("</OSCPACKET>").toString();
        return xml;
    }

    public byte[] getByteArray()
        throws IOException
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream stream = new DataOutputStream(baos);
        if(messages.size() > 1)
        {
            baos.write("#bundle".getBytes());
            baos.write(0);
            stream.writeLong(time);
        }
        byte byteArray[];
        for(Enumeration m = messages.elements(); m.hasMoreElements(); baos.write(byteArray))
        {
            OscMessage mess = (OscMessage)m.nextElement();
            byteArray = mess.getByteArray();
            if(messages.size() > 1)
                stream.writeInt(byteArray.length);
        }

        return baos.toByteArray();
    }

    private void alignStream(ByteArrayOutputStream stream)
        throws IOException
    {
        int pad = 4 - stream.size() % 4;
        for(int i = 0; i < pad; i++)
            stream.write(0);

    }

    public static void printBytes(byte byteArray[])
    {
        for(int i = 0; i < byteArray.length; i++)
        {
            System.out.print((new StringBuilder(String.valueOf(byteArray[i]))).append(" (").append((char)byteArray[i]).append(")  ").toString());
            if((i + 1) % 4 == 0)
                System.out.print("\n");
        }

    }

    private long time;
    private Vector messages;
    public InetAddress address;
    public int port;
}
