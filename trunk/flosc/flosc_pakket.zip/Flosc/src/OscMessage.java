// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OscMessage.java

import java.io.*;
import java.util.Enumeration;
import java.util.Vector;

public class OscMessage
{

    public OscMessage(String name)
    {
        this.name = name;
        types = new Vector();
        arguments = new Vector();
    }

    public void addArg(Character type, Object argument)
    {
        types.addElement(type);
        arguments.addElement(argument);
    }

    public void setTypesAndArgs(Vector types, Vector args)
    {
        this.types = types;
        arguments = args;
    }

    public String getXml()
    {
        if(types == null)
            return "ERROR: Types not set";
        String xml = "";
        xml = (new StringBuilder(String.valueOf(xml))).append("<MESSAGE NAME=\"").append(name).append("\">").toString();
        Enumeration t = types.elements();
        Enumeration a = arguments.elements();
        while(t.hasMoreElements()) 
        {
            char type = ((Character)t.nextElement()).charValue();
            if(type == '[')
                xml = (new StringBuilder(String.valueOf(xml))).append("<ARRAY>").toString();
            else
            if(type == ']')
            {
                xml = (new StringBuilder(String.valueOf(xml))).append("</ARRAY>").toString();
            } else
            {
                xml = (new StringBuilder(String.valueOf(xml))).append("<ARGUMENT TYPE=\"").append(type).append("\" ").toString();
                switch(type)
                {
                case 105: // 'i'
                    xml = (new StringBuilder(String.valueOf(xml))).append("VALUE=\"").append((Integer)a.nextElement()).append("\" />").toString();
                    break;

                case 102: // 'f'
                    xml = (new StringBuilder(String.valueOf(xml))).append("VALUE=\"").append((Float)a.nextElement()).append("\" />").toString();
                    break;

                case 104: // 'h'
                    xml = (new StringBuilder(String.valueOf(xml))).append("VALUE=\"").append((Long)a.nextElement()).append("\" />").toString();
                    break;

                case 100: // 'd'
                    xml = (new StringBuilder(String.valueOf(xml))).append("VALUE=\"").append((Double)a.nextElement()).append("\" />").toString();
                    break;

                case 115: // 's'
                    xml = (new StringBuilder(String.valueOf(xml))).append("VALUE=\"").append((String)a.nextElement()).append("\" />").toString();
                    break;

                case 70: // 'F'
                case 73: // 'I'
                case 78: // 'N'
                case 84: // 'T'
                    xml = (new StringBuilder(String.valueOf(xml))).append(" />").toString();
                    break;
                }
            }
        }
        xml = (new StringBuilder(String.valueOf(xml))).append("</MESSAGE>").toString();
        return xml;
    }

    public byte[] getByteArray()
        throws IOException
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream stream = new DataOutputStream(baos);
        stream.writeBytes(name);
        alignStream(baos);
        stream.writeByte(44);
        Enumeration t;
        char type;
        for(t = types.elements(); t.hasMoreElements(); stream.writeByte(type))
            type = ((Character)t.nextElement()).charValue();

        alignStream(baos);
        t = types.elements();
        Enumeration a = arguments.elements();
        while(t.hasMoreElements()) 
        {
            char ttype = ((Character)t.nextElement()).charValue();
            switch(ttype)
            {
            case 105: // 'i'
                stream.writeInt(((Integer)a.nextElement()).intValue());
                break;

            case 102: // 'f'
                stream.writeFloat(((Float)a.nextElement()).floatValue());
                break;

            case 104: // 'h'
                stream.writeLong(((Long)a.nextElement()).longValue());
                break;

            case 100: // 'd'
                stream.writeDouble(((Double)a.nextElement()).doubleValue());
                break;

            case 115: // 's'
                stream.writeBytes((String)a.nextElement());
                alignStream(baos);
                break;
            }
        }
        return baos.toByteArray();
    }

    private void alignStream(ByteArrayOutputStream stream)
        throws IOException
    {
        int pad = 4 - stream.size() % 4;
        for(int i = 0; i < pad; i++)
            stream.write(0);

    }

    private String name;
    private Vector types;
    private Vector arguments;
}
