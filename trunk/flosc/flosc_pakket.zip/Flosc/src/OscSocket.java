// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   OscSocket.java

import java.io.IOException;
import java.net.*;

public class OscSocket extends DatagramSocket
{

    public OscSocket()
        throws SocketException
    {
    }

    public void send(OscPacket oscPacket)
        throws IOException
    {
        byte byteArray[] = oscPacket.getByteArray();
        DatagramPacket packet = new DatagramPacket(byteArray, byteArray.length, oscPacket.getAddress(), oscPacket.getPort());
        send(packet);
    }
}
