// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TcpClient.java

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class TcpClient extends Thread
{

    public TcpClient(TcpServer server, Socket socket)
    {
        this.server = server;
        this.socket = socket;
        ip = socket.getInetAddress().getHostAddress();
        try
        {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
        }
        catch(IOException ioe)
        {
            Gateway.writeActivity((new StringBuilder("Client IP: ")).append(ip).append(" could not be ").append("initialized and has been disconnected.").toString());
            killClient();
        }
    }

    public void run()
    {
        try
        {
            StringBuffer stringBuffer;
            for(char charBuffer[] = new char[1]; in.read(charBuffer, 0, 1) != -1; server.handleOsc(stringBuffer.toString()))
            {
                stringBuffer = new StringBuffer(8192);
                while(charBuffer[0] != 0) 
                {
                    stringBuffer.append(charBuffer[0]);
                    in.read(charBuffer, 0, 1);
                }
            }

        }
        catch(IOException ioe)
        {
            Gateway.writeActivity((new StringBuilder("Client IP: ")).append(ip).append(" caused a read error ").append(ioe).append(" : ").append(ioe.getMessage()).append("and has been disconnected.").toString());
        }
        killClient();
    }

    public String getIP()
    {
        return ip;
    }

    public void send(String message)
    {
        out.print(message);
        if(out.checkError())
        {
            Gateway.writeActivity((new StringBuilder("Client IP: ")).append(ip).append(" caused a write error ").append("and has been disconnected.").toString());
            killClient();
        }
    }

    private void killClient()
    {
        server.removeClient(this);
        try
        {
            in.close();
            out.close();
            socket.close();
            thrThis = null;
        }
        catch(IOException ioe)
        {
            Gateway.writeActivity((new StringBuilder("Client IP: ")).append(ip).append(" caused an error ").append("while disconnecting.").toString());
        }
    }

    private Thread thrThis;
    private Socket socket;
    private TcpServer server;
    private String ip;
    protected BufferedReader in;
    protected PrintWriter out;
}
